Crypto Lab PWA｜安裝與發布說明

檔案：
- index.html：手機版行情學習頁面
- manifest.json：網頁 App 設定
- sw.js：快取首頁資源（行情 API 仍需網路）
- icon-192.png / icon-512.png：App 圖示

重要：
1. 這是一個可發布成 PWA 的網站原型，不代表已經有公開網址。
2. 要讓 iPhone Safari 透過網址開啟並加入主畫面，需要將整個資料夾部署到支援 HTTPS 的靜態網站主機。
3. 行情資料需要網路；離線時只能開啟已快取的介面，不能更新報價。
4. 目前行情、指標只供教育觀察，不含真實交易或下單功能。

iPhone 安裝：
網站部署完成後，用 Safari 開啟 HTTPS 網址 → 分享 → 加入主畫面。

部署：
將資料夾內所有檔案原樣上傳到支援 HTTPS 的靜態網站主機，並確保 index.html 位於網站根目錄。
